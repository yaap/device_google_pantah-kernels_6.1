/* SPDX-License-Identifier: GPL-2.0 */

#ifndef __ABI_CSKY_VDSO_H
#define __ABI_CSKY_VDSO_H

/* movi r7, 173 */
#define SET_SYSCALL_ID	.long 0x008bea07

#endif /* __ABI_CSKY_VDSO_H */
