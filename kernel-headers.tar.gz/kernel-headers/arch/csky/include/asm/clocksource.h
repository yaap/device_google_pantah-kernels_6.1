/* SPDX-License-Identifier: GPL-2.0 */

#ifndef __ASM_VDSO_CSKY_CLOCKSOURCE_H
#define __ASM_VDSO_CSKY_CLOCKSOURCE_H

#include <asm/vdso/clocksource.h>

#endif
