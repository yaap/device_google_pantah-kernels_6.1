/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef __ASM_VDSO_CSKY_PROCESSOR_H
#define __ASM_VDSO_CSKY_PROCESSOR_H

#ifndef __ASSEMBLY__

#define cpu_relax()	barrier()

#endif /* __ASSEMBLY__ */

#endif /* __ASM_VDSO_CSKY_PROCESSOR_H */
