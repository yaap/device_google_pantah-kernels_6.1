/* SPDX-License-Identifier: GPL-2.0 */

#ifndef __ASM_CSKY_SHMPARAM_H
#define __ASM_CSKY_SHMPARAM_H

#define SHMLBA	(4 * PAGE_SIZE)

#define __ARCH_FORCE_SHMLBA

#endif /* __ASM_CSKY_SHMPARAM_H */
