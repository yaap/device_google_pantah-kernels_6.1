/* SPDX-License-Identifier: GPL-2.0 */

#ifndef _CSKY_STRING_MM_H_
#define _CSKY_STRING_MM_H_

#ifndef __ASSEMBLY__
#include <linux/types.h>
#include <linux/compiler.h>
#include <abi/string.h>
#endif

#endif /* _CSKY_STRING_MM_H_ */
