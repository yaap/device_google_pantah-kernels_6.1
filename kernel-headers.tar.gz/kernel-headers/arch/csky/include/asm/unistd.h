/* SPDX-License-Identifier: GPL-2.0 */

#include <uapi/asm/unistd.h>

#define NR_syscalls (__NR_syscalls)
