/* SPDX-License-Identifier: GPL-2.0 */
#ifdef CONFIG_TOSHIBA_RBTX4927
BOARD_VEC(rbtx4927_vec)
BOARD_VEC(rbtx4937_vec)
#endif
