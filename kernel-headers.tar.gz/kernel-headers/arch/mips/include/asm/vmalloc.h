#ifndef _ASM_MIPS_VMALLOC_H
#define _ASM_MIPS_VMALLOC_H

#endif /* _ASM_MIPS_VMALLOC_H */
