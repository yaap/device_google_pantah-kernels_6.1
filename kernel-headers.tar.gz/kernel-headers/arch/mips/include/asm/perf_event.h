/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * linux/arch/mips/include/asm/perf_event.h
 *
 * Copyright (C) 2010 MIPS Technologies, Inc.
 * Author: Deng-Cheng Zhu
 */

#ifndef __MIPS_PERF_EVENT_H__
#define __MIPS_PERF_EVENT_H__
/* Leave it empty here. The file is required by linux/perf_event.h */
#endif /* __MIPS_PERF_EVENT_H__ */
